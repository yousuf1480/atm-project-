#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <string.h>

#define PIN_CODE 9877
#define DAILY_LIMIT 20000
#define MAX_HISTORY 100   // Max transactions history

unsigned long savingBalance = 50000;
unsigned long currentBalance = 100000;
unsigned long deposit, withdraw;
unsigned long dailyWithdraw = 0;

int choice, k = 0;
int accType;
char transaction = 'y';

/* -------- Transaction History -------- */
typedef struct {
    char transType[20];
    unsigned long amount;
    unsigned long balance;
    char timeStr[30];
} Transaction;

Transaction history[MAX_HISTORY];
int historyCount = 0;

/* -------- SLIP FUNCTION -------- */
void printSlip(char transType[], unsigned long amount,
               unsigned long balance, char accName[]) {

    FILE *fp;
    time_t now = time(NULL);
    char timeBuf[30];
    strcpy(timeBuf, ctime(&now));
    timeBuf[strlen(timeBuf)-1] = '\0'; // remove newline

    // File write
    fp = fopen("receipt.txt", "a");
    if(fp != NULL){
        fprintf(fp, "\n=================================\n");
        fprintf(fp, "        ABC BANK LIMITED          \n");
        fprintf(fp, "           ATM SLIP               \n");
        fprintf(fp, "=================================\n");
        fprintf(fp, "Account Type : %s\n", accName);
        fprintf(fp, "Transaction  : %s\n", transType);
        if(amount==0)
            fprintf(fp, "Amount       : N/A\n");
        else
            fprintf(fp, "Amount       : %lu PKR\n", amount);
        fprintf(fp, "Balance      : %lu PKR\n", balance);
        fprintf(fp, "Daily Limit  : %d PKR\n", DAILY_LIMIT);
        fprintf(fp, "Date & Time  : %s\n", timeBuf);
        fprintf(fp, "=================================\n");
        fprintf(fp, "   Thank You For Using Our ATM    \n");
        fprintf(fp, "=================================\n");
        fclose(fp);
    }

    // Screen print
    printf("\n--------- ATM SLIP ---------\n");
    printf("Bank        : ABC BANK\n");
    printf("Account     : %s\n", accName);
    printf("Transaction : %s\n", transType);
    if(amount==0)
        printf("Amount      : N/A\n");
    else
        printf("Amount      : %lu PKR\n", amount);
    printf("Balance     : %lu PKR\n", balance);
    printf("Date & Time : %s\n", timeBuf);
    printf("----------------------------\n");

    // Save in transaction history
    if(historyCount < MAX_HISTORY){
        strcpy(history[historyCount].transType, transType);
        history[historyCount].amount = amount;
        history[historyCount].balance = balance;
        strcpy(history[historyCount].timeStr, timeBuf);
        historyCount++;
    }
}

/* -------- Show Transaction History -------- */
void showHistory(){
    if(historyCount == 0){
        printf("\nNo transaction history available.\n");
        return;
    }
    printf("\n------ Transaction History ------\n");
    for(int i=0; i<historyCount; i++){
        printf("%d. %s | Amount: %lu | Balance: %lu | %s\n",
               i+1, history[i].transType, history[i].amount, history[i].balance, history[i].timeStr);
    }
    printf("---------------------------------\n");
}

int main() {

    int attempts = 0;
    int enteredPin, i;
    char ch;
    unsigned long *balance;
    char accName[10];

    /* -------- Account Type -------- */
    printf("Select Account Type\n");
    printf("1. Saving Account\n");
    printf("2. Current Account\n");
    printf("Enter Choice: ");
    scanf("%d", &accType);

    if (accType == 1) {
        balance = &savingBalance;
        sprintf(accName, "Saving");
    }
    else if (accType == 2) {
        balance = &currentBalance;
        sprintf(accName, "Current");
    }
    else {
        printf("Invalid Account Type\n");
        return 0;
    }

    /* -------- PIN (Hidden) -------- */
    while (attempts < 3) {
        printf("\nEnter PIN: ");
        enteredPin = 0;

        for (i = 0; i < 4; i++) {
            ch = getch();
            printf("*");
            enteredPin = enteredPin * 10 + (ch - '0');
        }

        if (enteredPin == PIN_CODE)
            break;
        else {
            attempts++;
            printf("\nWrong PIN (%d/3)\n", attempts);
        }
    }

    if (attempts == 3) {
        printf("\nCARD BLOCKED!\n");
        return 0;
    }

    /* -------- ATM MENU -------- */
    do {
        printf("\n\n******** ATM MENU ********\n");
        printf("1. Check Balance\n");
        printf("2. Withdraw Cash\n");
        printf("3. Deposit Cash\n");
        printf("4. Show Transaction History\n");
        printf("5. Quit\n");
        printf("Enter Choice: ");
        scanf("%d", &choice);

        switch (choice) {

        case 1:
            printf("Balance: %lu PKR\n", *balance);
            printSlip("Balance Inquiry", 0, *balance, accName);
            break;

        case 2:
            printf("Enter Withdraw Amount: ");
            scanf("%lu", &withdraw);

            if (withdraw % 500 != 0)
                printf("Enter multiples of 500\n");
            else if (withdraw > *balance - 500)
                printf("Insufficient Balance\n");
            else if (dailyWithdraw + withdraw > DAILY_LIMIT)
                printf("Daily Limit Exceeded\n");
            else {
                *balance -= withdraw;
                dailyWithdraw += withdraw;
                printf("Collect Your Cash\n");
                printSlip("Cash Withdraw", withdraw, *balance, accName);
            }
            break;

        case 3:
            printf("Enter Deposit Amount: ");
            scanf("%lu", &deposit);
            *balance += deposit;
            printSlip("Cash Deposit", deposit, *balance, accName);
            break;

        case 4:
            showHistory();
            break;

        case 5:
            printf("Thank You For Using ATM\n");
            k = 1;
            break;

        default:
            printf("Invalid Choice\n");
        }

        if (!k) {
            printf("\nAnother Transaction? (y/n): ");
            scanf(" %c", &transaction);
            if (transaction == 'n' || transaction == 'N')
                k = 1;
        }

    } while (!k);

    return 0;
}

