#include <stdio.h>
#include <time.h>
#include <conio.h>   // for getch()

unsigned long amount = 50000, deposit, withdraw;
int choice, pin = 0, k = 0;
char transaction = 'y';
int accType;

int main() {

    int enteredPin, i;
    char ch;
    
    // -------- Account Type Selection --------
    printf("Select Account Type:\n");
    printf("1. Saving Account\n");
    printf("2. Current Account\n");
    printf("Enter Your Choice: ");
    scanf("%d", &accType);

    if (accType == 1)
        printf("Saving Account Selected\n");
    else if (accType == 2)
        printf("Current Account Selected\n");
    else {
        printf("Invalid Account Type\n");
        return 0;
    }

    // -------- PIN Validation (Hidden PIN) --------
    while (pin != 9877) {
        printf("\nEnter Your PIN: ");
        enteredPin = 0;

        for (i = 0; i < 4; i++) {
            ch = getch();        // no echo on screen
            printf("*");         // show *
            enteredPin = enteredPin * 10 + (ch - '0');
        }

        pin = enteredPin;

        if (pin != 9877) {
            printf("\a\nInvalid PIN! Try Again\n");
        }
    }

    // -------- ATM Menu --------
    do {
        printf("\n\n******** Welcome To ATM ********\n");

        time_t current_time = time(NULL);
        printf("%s\n", ctime(&current_time));

        printf("1. Check Balance\n");
        printf("2. Withdraw Cash\n");
        printf("3. Deposit Cash\n");
        printf("4. Quit\n");
        printf("Enter Your Choice: ");
        scanf("%d", &choice);

        switch (choice) {

        case 1:
            printf("Your Balance: %lu PKR\n", amount);
            break;

        case 2:
            printf("Enter Amount to Withdraw: ");
            scanf("%lu", &withdraw);

            if (withdraw % 500 != 0) {
                printf("\aEnter amount in multiples of 500\n");
            }
            else if (withdraw > amount - 500) {
                printf("\aInsufficient Balance\n");
            }
            else {
                amount -= withdraw;
                printf("Please Collect Your Cash\n");
            }
            break;

        case 3:
            printf("Enter Amount to Deposit: ");
            scanf("%lu", &deposit);
            amount += deposit;
            printf("Cash Deposited Successfully\n");
            break;

        case 4:
            printf("Thank You for Using ATM\n");
            k = 1;
            break;

        default:
            printf("\aInvalid Choice\n");
        }

        if (!k) {
            printf("\nDo You Want Another Transaction? (y/n): ");
            scanf(" %c", &transaction);
            if (transaction == 'n' || transaction == 'N')
                k = 1;
        }

    } while (!k);

    return 0;
}

