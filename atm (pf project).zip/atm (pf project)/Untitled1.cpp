#include<stdio.h>
struct student{
	char name[50];
	float marks;
	int roll;
};
int main (){
	struct student s1;
	printf("Name = %s",s1.name);
	scanf("%s",s1.name);
	printf("Marks = %.2f",s1.marks);
	scanf("%.2f",&s1.marks);
	return 0
	;
}
