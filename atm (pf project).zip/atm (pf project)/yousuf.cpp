#include <stdio.h>
#include <time.h>

unsigned long amount = 50000, deposit, withdraw;
int choice, pin = 0, k = 0;
char transation = 'y';

int main() {

    // PIN validation
    while (pin != 9877) {
        printf("Enter Your Pin Number: ");
        scanf("%d", &pin);

        if (pin != 9877) {
            printf("\a");
            printf("Invalid PIN! Please Enter Valid Pin\n");
        }
    }

    do {
        printf("\n********Welcome To ATM Service********\n");

        // Date and time
        time_t current_time = time(NULL);
        printf("%s\n", ctime(&current_time));

        printf("1. Check Balance\n");
        printf("2. Withdraw Cash\n");
        printf("3. Deposit Cash\n");
        printf("4. Quit\n");
        printf("Enter Your Choice: ");
        scanf("%d", &choice);

        switch (choice) {

        case 1:
            printf("\nYOUR BALANCE IN PKR: %lu\n", amount);
            break;

        case 2:
            printf("\nENTER AMOUNT TO WITHDRAW: ");
            scanf("%lu", &withdraw);

            if (withdraw % 500 != 0) {
                printf("\a");
                printf("Enter amount in multiples of 500\n");
            }
            else if (withdraw > amount - 500) {
                printf("\a");
                printf("Insufficient balance\n");
            }
            else {
                amount -= withdraw;
                printf("Please collect cash\nThankyou for using our atm ");
            }
            break;

        case 3:
            printf("\nENTER AMOUNT TO DEPOSIT: ");
            scanf("%lu", &deposit);
            amount += deposit;
            printf("Cash deposited successfully\n");
            break;

        case 4:
            printf("Thank You for Using ATM\n");
            k = 1;
            break;

        default:
            printf("\a");
            printf("Invalid Choice\n");
        }

        if (!k) {
            printf("\nDo You Want Another Transaction? (y/n): ");
            scanf(" %c", &transation);
            if (transation == 'n' || transation == 'N')
                k = 1;
        }

    } while (!k);

    printf("\nThank You for Using Our ATM Machine\n");
    return 0;
}
